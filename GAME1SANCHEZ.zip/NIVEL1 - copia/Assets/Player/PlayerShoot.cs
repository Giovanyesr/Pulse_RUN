using UnityEngine;
using System.Collections;

public class PlayerShoot : MonoBehaviour
{
    [Header("General Shooting")]
    public GameObject bulletPrefab;
    public Transform firePoint;
    public float fireRate = 0.25f;

    private float nextFireTime = 0f;

    [Header("Triple Shot")]
    private bool isTripleShotActive = false;

    void Update()
    {
        if (Input.GetKey(KeyCode.Space) && Time.time >= nextFireTime)
        {
            Shoot();
            nextFireTime = Time.time + fireRate;
        }
    }

    void Shoot()
    {
        if (isTripleShotActive)
        {
            // Disparo triple
            Instantiate(bulletPrefab, firePoint.position, firePoint.rotation);

            // Ligeras rotaciones izquierda y derecha
            Instantiate(bulletPrefab, firePoint.position, Quaternion.Euler(0, 0, 15));
            Instantiate(bulletPrefab, firePoint.position, Quaternion.Euler(0, 0, -15));
        }
        else
        {
            // Disparo normal
            Instantiate(bulletPrefab, firePoint.position, firePoint.rotation);
        }
    }

    // 🔑 Método que activa el TripleShot (llamado desde PowerUp.cs)
    public void ActivateTripleShot(float duration)
    {
        StartCoroutine(TripleShotRoutine(duration));
    }

    private IEnumerator TripleShotRoutine(float duration)
    {
        isTripleShotActive = true;
        yield return new WaitForSeconds(duration);
        isTripleShotActive = false;
    }
}
