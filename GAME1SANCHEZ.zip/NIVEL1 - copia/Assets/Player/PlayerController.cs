using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
[RequireComponent(typeof(Animator))]
public class PlayerController : MonoBehaviour
{
    [Header("Movement")]
    public float moveSpeed = 5f;
    public float jumpForce = 7f;

    [Header("Ground Check")]
    public Transform groundCheck;           // Empty debajo del Player
    public float groundCheckRadius = 0.15f; // 0.12 - 0.2 según tu sprite
    public LayerMask groundLayer;           // Asigna "Ground" en el Inspector

    private Rigidbody2D rb;
    private Animator animator;
    private bool isGrounded;
    private float move;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
    }

    void Update()
    {
        // --- Movimiento horizontal ---
        move = Input.GetAxis("Horizontal");
        rb.linearVelocity = new Vector2(move * moveSpeed, rb.linearVelocity.y);

        // --- Flip sprite según dirección ---
        if (move != 0)
            transform.localScale = new Vector3(Mathf.Sign(move), 1, 1);

        // --- Saltar solo si está en el suelo ---
        if (Input.GetButtonDown("Jump") && isGrounded)
        {
            rb.linearVelocity = new Vector2(rb.linearVelocity.x, jumpForce);
            animator.SetTrigger("Jump");
        }

        // --- Verificar si está en el suelo ---
        isGrounded = Physics2D.OverlapCircle(groundCheck.position, groundCheckRadius, groundLayer);

        // --- Animaciones ---
        animator.SetBool("IsRunning", move != 0);
        animator.SetBool("IsGrounded", isGrounded);
        animator.SetFloat("yVelocity", rb.linearVelocity.y); // Para distinguir salto/caída
    }

    void OnDrawGizmosSelected()
    {
        if (groundCheck != null)
        {
            Gizmos.color = Color.red;
            Gizmos.DrawWireSphere(groundCheck.position, groundCheckRadius);
        }
    }
}
