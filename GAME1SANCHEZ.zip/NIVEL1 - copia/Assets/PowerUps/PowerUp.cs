using UnityEngine;

public class PowerUp : MonoBehaviour
{
    public enum PowerUpType { TripleShot, Health }
    public PowerUpType type;

    public float duration = 8f; // solo para TripleShot
    public int amount = 25;     // solo para Health

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            if (type == PowerUpType.TripleShot)
            {
                PlayerShoot shooter = collision.GetComponent<PlayerShoot>();
                if (shooter != null)
                {
                    shooter.ActivateTripleShot(duration);
                }
            }
            else if (type == PowerUpType.Health)
            {
                PlayerHealth health = collision.GetComponent<PlayerHealth>();
                if (health != null)
                {
                    health.Heal(amount);
                }
            }

            Destroy(gameObject); // el power-up desaparece al ser tomado
        }
    }
}
