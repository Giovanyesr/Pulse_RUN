public enum PowerUpType
{
    TripleShot,
    Health
}
