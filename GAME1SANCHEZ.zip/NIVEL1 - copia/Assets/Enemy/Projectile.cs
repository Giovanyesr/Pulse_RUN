using UnityEngine;

public class Projectile : MonoBehaviour
{
    public float _speed = 18f;
    public float _lifeTime = 2f;
    public int _damage = 25;

    private Rigidbody2D rb;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        rb.linearVelocity = transform.right * _speed; // la bala se mueve hacia la derecha local
        Destroy(gameObject, _lifeTime); // se destruye sola después de 2s
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        // Aquí puedes chequear si golpea enemigos
        if (collision.CompareTag("Enemy"))
        {
            // TODO: aplicar daño al enemigo
            Debug.Log("Enemy hit! -" + _damage);
        }

        Destroy(gameObject); // destruir la bala al impactar
    }
}
