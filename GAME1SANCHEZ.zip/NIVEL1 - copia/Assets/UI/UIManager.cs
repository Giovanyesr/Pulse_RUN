using UnityEngine;
using UnityEngine.UI;

public class UIManager : MonoBehaviour
{
    public static UIManager Instance;

    public Text scoreText;
    public Slider healthBar;

    private int score;

    void Awake() => Instance = this;

    public void UpdateScore(int amount)
    {
        score += amount;
        scoreText.text = "Score: " + score;
    }

    public void UpdateHealth(int hp)
    {
        healthBar.value = hp;
    }
}
